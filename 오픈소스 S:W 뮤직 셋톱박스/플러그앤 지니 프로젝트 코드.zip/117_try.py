#!/usr/bin/python
#--------------------------------------
#    ___  ___  _ ____
#   / _ \/ _ \(_) __/__  __ __
#  / , _/ ___/ /\ \/ _ \/ // /
# /_/|_/_/  /_/___/ .__/\_, /
#                /_/   /___/
#
#  lcd_i2c.py
#  LCD test script using I2C backpack.
#  Supports 16x2 and 20x4 screens.
#
# Author : Matt Hawkins
# Date   : 20/09/2015
#
# http://www.raspberrypi-spy.co.uk/
#
# Copyright 2015 Matt Hawkins
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#--------------------------------------
#!/usr/bin/env python

import ftplib
import smbus
import time
import vlc
import RPi.GPIO as GPIO
import os

#button settings
GPIO.setmode(GPIO.BCM)
GPIO.setup(17, GPIO.IN) #stop
GPIO.setup(18, GPIO.IN) #play, pause
GPIO.setup(19, GPIO.IN) #previous song
GPIO.setup(20, GPIO.IN) #next song
GPIO.setup(21, GPIO.IN) #channel down
GPIO.setup(22, GPIO.IN) #channel up


# Define some device parameters
I2C_ADDR  = 0x27 # I2C device address
LCD_WIDTH = 16   # Maximum characters per line

# Define some device constants
LCD_CHR = 1 # Mode - Sending data
LCD_CMD = 0 # Mode - Sending command

LCD_LINE_1 = 0x80 # LCD RAM address for the 1st line
LCD_LINE_2 = 0xC0 # LCD RAM address for the 2nd line
LCD_LINE_3 = 0x94 # LCD RAM address for the 3rd line
LCD_LINE_4 = 0xD4 # LCD RAM address for the 4th line

LCD_BACKLIGHT  = 0x08  # On
#LCD_BACKLIGHT = 0x00  # Off

ENABLE = 0b00000100 # Enable bit

# Timing constants
E_PULSE = 0.0005
E_DELAY = 0.0005

#Open I2C interface
#bus = smbus.SMBus(0)  # Rev 1 Pi uses 0
bus = smbus.SMBus(1) # Rev 2 Pi uses 1

def lcd_init():
  # Initialise display
  lcd_byte(0x33,LCD_CMD) # 110011 Initialise
  lcd_byte(0x32,LCD_CMD) # 110010 Initialise
  lcd_byte(0x06,LCD_CMD) # 000110 Cursor move direction
  lcd_byte(0x0C,LCD_CMD) # 001100 Display On,Cursor Off, Blink Off 
  lcd_byte(0x28,LCD_CMD) # 101000 Data length, number of lines, font size
  lcd_byte(0x01,LCD_CMD) # 000001 Clear display
  time.sleep(E_DELAY)

def lcd_byte(bits, mode):
  # Send byte to data pins
  # bits = the data
  # mode = 1 for data
  #        0 for command

  bits_high = mode | (bits & 0xF0) | LCD_BACKLIGHT
  bits_low = mode | ((bits<<4) & 0xF0) | LCD_BACKLIGHT

  # High bits
  bus.write_byte(I2C_ADDR, bits_high)
  lcd_toggle_enable(bits_high)

  # Low bits
  bus.write_byte(I2C_ADDR, bits_low)
  lcd_toggle_enable(bits_low)

def lcd_toggle_enable(bits):
  # Toggle enable
  time.sleep(E_DELAY)
  bus.write_byte(I2C_ADDR, (bits | ENABLE))
  time.sleep(E_PULSE)
  bus.write_byte(I2C_ADDR,(bits & ~ENABLE))
  time.sleep(E_DELAY)

def lcd_string(message,line):
  # Send string to display

  message = message.ljust(LCD_WIDTH," ")

  lcd_byte(line, LCD_CMD)

  for i in range(LCD_WIDTH):
    lcd_byte(ord(message[i]),LCD_CHR)


  

def main():
  # Main program block

  # Initialise display
  path = ["/home/pi/Music/classic/", "/home/pi/Music/kpop/", "/home/pi/Music/pop/"]
   
  j = 0
  root = ftplib.FTP('192.168.0.77','root','openmediavault')

  #time.sleep(3)
  
  root.cwd('/number1/classics/')  
  list1 = root.nlst()
  while j<len(list1):
    if not os.path.isfile("/home/pi/Music/classic/"+list1[j]):
      fd = open("/home/pi/Music/classic/"+list1[j], 'wb')
      root.retrbinary("RETR /number1/classics/"+list1[j], fd.write)
      fd.close()
    j+=1
  j=0
  
  root.cwd('/number1/korean/')
  list2 = root.nlst()
  while j<len(list2):
    if not os.path.isfile("/home/pi/Music/kpop/"+list2[j]):
      fd = open("/home/pi/Music/kpop/"+list2[j], 'wb')
      root.retrbinary("RETR /number1/korean/"+list2[j], fd.write)
      fd.close()
    j+=1
  j=0
  
  root.cwd('/number1/pop/')
  list3 = root.nlst()
  while j<len(list3):
    if not os.path.isfile("/home/pi/Music/pop/"+list3[j]):
      fd = open("/home/pi/Music/pop/"+list3[j], 'wb')
      root.retrbinary("RETR /number1/pop/"+list3[j], fd.write)
      fd.close()
    j+=1
  j=0
  
  #root.cwd('/number1/z_log/')
  #list0 = root.nlst()
  #loader = open("save.txt", 'r')
  #saved = loader.readline()

  #slot = []
  #slot.append(saved)
  #list0.remove(saved)

  lcd_init()
  
 # list1 = slot+list1
 # loader.close()
  
  path = ["/home/pi/Music/classic/", "/home/pi/Music/kpop/", "/home/pi/Music/pop/"]
  #path = ["ftp://192.168.0.77/number1/classics/", "ftp://192.168.0.77/number1/korean/", "ftp://192.168.0.77/number1/pop/"]
  #a = os.listdir(path)

  loader1 = open("/home/pi/channel.txt", 'r')
  i = str(loader1.readline())
  #str(i)
  loader1.close()
  print(i)
  i = int((float(i)))
  
  loader2 = open("/home/pi/channel2.txt", 'r')
  channel = str(loader2.readline())
  #str(channel)
  loader2.close()
  print(channel)
  channel = int((float(channel)))

  
  
  file = (path[i]+os.listdir(path[i])[channel])

  
  instance = vlc.Instance()

  player=instance.media_player_new()

  media=instance.media_new(file)

  player.set_media(media)

  player.play()
  time.sleep(1)

  count = player.get_state()

  while True:
    count = player.get_state()
    if count == 6:
      channel += 1                                                   
      file = (path[i]+os.listdir(path[i])[channel])
      instance = vlc.Instance()
      player= instance.media_player_new()
      media = instance.media_new(file)
      player.set_media(media)
      
      player.play()
      time.sleep(1)

    if GPIO.input(17)==0:
        count=player.get_state()

        f1 = open("/home/pi/channel.txt", 'w')
        data1 = i
        hhh = str(data1)
        print(data1)
        f1.write(hhh)
        print(data1)
        f1.close()


        f2 = open("/home/pi/channel2.txt", 'w')
        data2 = channel
        hhh2 = str(channel)
        f2.write(hhh2)
        f2.close()
        
        player.stop()
        count=player.get_state()
        time.sleep(1)

        
        
    #if count==3:
     #   player.stop()
        
    elif GPIO.input(18)==0:
        player.pause()
        count=player.get_state()
        time.sleep(1)
        
    if GPIO.input(19)==0: #track before
      if channel == 0:
        channel = len(os.listdir(path[i]))
      player.stop()
      channel -= 1
      file = (path[i]+os.listdir(path[i])[channel])
      instance = vlc.Instance()
      player= instance.media_player_new()
      media = instance.media_new(file)
      player.set_media(media)
      player.play()
      time.sleep(1)
      
      
    if GPIO.input(20)==0: #track after
      if channel == len(os.listdir(path[i]))-1:
        channel = -1
      player.stop()
      channel += 1
      file = (path[i]+os.listdir(path[i])[channel])
      instance = vlc.Instance()
      player= instance.media_player_new()
      media = instance.media_new(file)
      player.set_media(media)
      player.play()
      time.sleep(1)
      
          
      player.get_state()

    if GPIO.input(21)==0: #channel down
      if i == 0:
        i = 3
      player.stop()
      i -= 1
      channel = 0
      file = (path[i]+os.listdir(path[i])[channel])
      instance = vlc.Instance()
      player= instance.media_player_new()
      media = instance.media_new(file)
      player.set_media(media)
      player.play()
      time.sleep(1)

    if GPIO.input(22)==0: #channel up
      if i == 2:
        i = -1
      player.stop()
      i += 1
      channel = 0
      file = (path[i]+os.listdir(path[i])[channel])
      instance = vlc.Instance()
      player= instance.media_player_new()
      media = instance.media_new(file)
      player.set_media(media)
      player.play()
      time.sleep(1)
      

#    if channel == 0 or channel == -4:
#        lcd_string("Psy            ",LCD_LINE_1)
#        lcd_string("New Face       ", LCD_LINE_2)
#    if channel == 1 or channel == -3:
#        lcd_string("Zico           ",LCD_LINE_1)
#        lcd_string("She's a Baby   ", LCD_LINE_2)
#    if channel == 2 or channel == -2:
#        lcd_string("Sunmi          ",LCD_LINE_1)
#        lcd_string("Gasina         ", LCD_LINE_2)
#    if channel == 3 or channel == -1:
#        lcd_string("Zico           ",LCD_LINE_1)
#        lcd_string("Boys and Girls ", LCD_LINE_2)

    if i == 0 or i == -3:
      if channel == 0 or channel == -4:
        lcd_string("Prokofiev      ",LCD_LINE_1)
        lcd_string("Romeo & Juliet ", LCD_LINE_2)
      if channel == 1 or channel == -3:
        lcd_string("Khachaturian   ",LCD_LINE_1)
        lcd_string("Masquerade     ", LCD_LINE_2)
      if channel == 2 or channel == -2:
        lcd_string("Khachaturian   ",LCD_LINE_1)
        lcd_string("Spartacus      ", LCD_LINE_2)
      if channel == 3 or channel == -1:
        lcd_string("Rachmaninoff   ",LCD_LINE_1)
        lcd_string("Rhapsody       ", LCD_LINE_2)
        
    if i == 1 or i == -2:
      if channel == 0 or channel == -4:
        lcd_string("Psy            ",LCD_LINE_1)
        lcd_string("New Face       ", LCD_LINE_2)
      if channel == 1 or channel == -3:
        lcd_string("Zico           ",LCD_LINE_1)
        lcd_string("She's a Baby   ", LCD_LINE_2)
        
      if channel == 2 or channel == -2:
        lcd_string("Sunmi          ",LCD_LINE_1)
        lcd_string("Gasina         ", LCD_LINE_2)
      if channel == 3 or channel == -1:
        lcd_string("Zico           ",LCD_LINE_1)
        lcd_string("Boys and Girls ", LCD_LINE_2)
        
    if i == 2 or i == -1:
      if channel == 0 or channel == -4:
        lcd_string("Little Mix     ",LCD_LINE_1)
        lcd_string("Shoutout to My Ex", LCD_LINE_2)
      if channel == 1 or channel == -3:
        lcd_string("Bruno Mars     ",LCD_LINE_1)
        lcd_string("24K Magic      ", LCD_LINE_2)
      if channel == 2 or channel == -2:
        lcd_string("Maroon 5       ",LCD_LINE_1)
        lcd_string("Don't Wanna know", LCD_LINE_2)
      if channel == 3 or channel == -1:
        lcd_string("Zara Larsson   ",LCD_LINE_1)
        lcd_string("Not My Fault   ", LCD_LINE_2)


if __name__ == '__main__':

  try:
    main()
  except KeyboardInterrupt:
    pass
  finally:
    lcd_byte(0x01, LCD_CMD)

